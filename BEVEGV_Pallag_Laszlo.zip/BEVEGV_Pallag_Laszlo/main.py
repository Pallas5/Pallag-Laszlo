from tkinter import *

global MelyikGomb
def SulySzamol(szam, szorzo):
    szoveg = str((round(szam*szorzo,2)))
    return szoveg

def Szamol():
    try:
        bekertSzam = bekeres.get()
        print(bekertSzam)
        szam= int(bekertSzam)
        input.set(szam)
        label3.place_forget()

        if MelyikGomb == "szervezo":
            label3.place_forget()
            vegeredmeny["text"] = "Zsír: "+SulySzamol(szam,0.07)+"kg\nHagyma: "+SulySzamol(szam,0.05)+"kg\nFüstölt szalonna: "+SulySzamol(szam,0.02)+"kg\nKolbász: "+SulySzamol(szam,0.02)+"kg\nPirosarany csemege: "+SulySzamol(szam,0.02)+"db\nPirosarany csípős: "+SulySzamol(szam,0.02)+"db\nGulyáskrém: "+SulySzamol(szam,0.02)+"db\nFokhagymakrém: "+SulySzamol(szam,0.02)+"db\nMajoros Fűszerkeverék: "+SulySzamol(szam,0.02)+"db\nSör: "+SulySzamol(szam,0.01)+"l"
            vegeredmeny.place(x=150, y=170, width=214, height=160)

        elif MelyikGomb == "gazdasz":
            label3.place_forget()
            vegeredmeny["text"] = "Darált hús: "+SulySzamol(szam,0.05)+"kg\nKolbász: "+SulySzamol(szam,0.05)+"kg\nZsír: "+SulySzamol(szam,0.08)+"kg\nHagyma: "+SulySzamol(szam,0.04)+"kg\nHúsvarázs: "+SulySzamol(szam,1.25)+"g\nBors: "+SulySzamol(szam,1.1)+"g\nMeggybor: "+SulySzamol(szam,0.03)+"l\nFokhagymakrém: "+SulySzamol(szam,0.02)+"db\nGulyáskrém: "+SulySzamol(szam,0.02)+"db\nPaprikakrém: "+SulySzamol(szam,0.02)+"db\n"
            vegeredmeny.place(x=150, y=170, width=214, height=170)
        else:
            label3.place_forget()
            vegeredmeny["text"] = "Zsír: "+SulySzamol(szam,0.05)+"kg\nDarált hús: "+SulySzamol(szam,0.03)+"kg\nHagyma: "+SulySzamol(szam,0.03)+"kg\nHúsvarázs: "+SulySzamol(szam,1.25)+"g\n"
            vegeredmeny.place(x=150, y=160, width=214, height=119)
    except:
        input.set("ERROR")
        label3.place(x=110, y=150, width=273, height=32)



def UjFelulet(melyikGomb):
    global MelyikGomb
    label1.place_forget()
    szervezoGomb.place_forget()
    gazdaszGomb.place_forget()
    gepeszGomb.place_forget()
    vissza["state"]="active"
    vissza.place(x=10, y=280, width=127, height=55)
    label2.place(x=170, y=10, width=155, height=30)
    bekeres.place(x=140, y=40, width=226, height=46)
    szamolGomb.place(x=200, y=100, width=100, height=55)
    MelyikGomb=melyikGomb




def visszaGomb():
    label1.place(x=110, y=40, width=273, height=32)
    szervezoGomb.place(x=60, y=120, width=75, height=78)
    gazdaszGomb.place(x=210, y=120, width=75, height=78)
    gepeszGomb.place(x=360, y=120, width=75, height=78)
    vissza["state"] = "disabled"
    label2.place_forget()
    bekeres.place_forget()
    szamolGomb.place_forget()
    label3.place_forget()
    vegeredmeny.place_forget()
    vissza.place_forget()
    input.set("")


if __name__ == '__main__':
    felulet = Tk()
    felulet.configure(background='blue')
    felulet.title("Zsírfőző kalkulátor")
    felulet.geometry("500x350")

    label1 = Label(felulet, text='Válaszd ki a megfelelő zsírt', bg='blue', fg='red', font=("Arial", 15))
    label1.place(x=110, y=40, width=273, height=32)

    label2 = Label(felulet, text='Add meg hány főre főzöl', bg='blue', fg='red', font=("Arial", 10))
    label2.place_forget()

    label3 = Label(felulet, text='Egész Számot adj meg!', bg='blue', fg='red', font=("Arial", 15))
    label3.place(x=110, y=150, width=273, height=32)
    label3.place_forget()

    vegeredmeny = Label(felulet, text='', bg='blue', fg='red', font=("Arial", 10))
    vegeredmeny.place(x=150, y=160, width=214, height=119)
    vegeredmeny.place_forget()

    input = StringVar()
    bekeres = Entry(felulet, textvariable=input, font=("Arial", 16))
    bekeres.grid(columnspan=4, ipadx=60)
    bekeres.delete(0,"end")
    bekeres.place(x=140, y=40, width=226, height=46)
    bekeres.place_forget()

    szervezoGomb = Button(felulet, text=' Szervező ', fg='black', bg='white', height=1, width=5, borderwidth=3, relief="groove", command=lambda:UjFelulet('szervezo'))
    szervezoGomb.grid(row=2, column=0)
    szervezoGomb.place(x=60, y=120, width=75, height=78)

    gazdaszGomb = Button(felulet, text=' Gazdász ', fg='black', bg='white', height=1, width=5, borderwidth=3, relief="groove", command=lambda:UjFelulet('gazdasz'))
    gazdaszGomb.grid(row=2, column=0)
    gazdaszGomb.place(x=210, y=120, width=75, height=78)

    gepeszGomb = Button(felulet, text=' Gépész ', fg='black', bg='white', height=1, width=5, borderwidth=3, relief="groove", command=lambda:UjFelulet('gepesz'))
    gepeszGomb.grid(row=2, column=0)
    gepeszGomb.place(x=360, y=120, width=75, height=78)

    szamolGomb = Button(felulet, text=' Számol ', fg='black', bg='white', height=1, width=5, borderwidth=3, relief="groove", command=lambda:Szamol())
    szamolGomb.grid(row=2, column=0)
    szamolGomb.place(x=200, y=100, width=100, height=55)
    szamolGomb.place_forget()

    vissza = Button(felulet, text=' Vissza ', fg='black', bg='white', height=1, width=5, borderwidth=3, relief="groove", state='disabled', command=lambda:visszaGomb())
    vissza.grid(row=2, column=0)
    vissza.place(x=10, y=280, width=127, height=55)
    vissza.place_forget()
    felulet.mainloop()